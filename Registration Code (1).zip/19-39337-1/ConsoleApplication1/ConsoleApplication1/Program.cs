﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Registration> User = new List<Registration>();
            Registration tempData = new Registration();
            int UserNo = 0,id;
            string Choice;

            while (true)
            {
                Console.Write("Press 1 for Login\nPress 2 for Sign Up\n-");
                Choice = Console.ReadLine();
                if (Choice == "1")
                {
                    if (User.Count > 0)
                    {
                        Console.Write("Give your Id\n-");
                        id = Convert.ToInt32(Console.ReadLine());
                        
                        User[id].Login(id);
                    }
                    else
                    {
                        Console.WriteLine("No User Exist");
                    }
                }
                else if (Choice == "2")
                {
                    tempData.SignUp(UserNo);
                    User.Add(tempData);
                    UserNo++;
                }
                else { Console.WriteLine("Wrong Input"); }
            }
        }
    }

    class Registration
    {
        public static int id;
        public string name;
        public string PhoneNo;
        private string password;

        public void Login(int tempId){

            Console.Write("Enter Your Password\n-");
            var tempPassword = Console.ReadLine();


            if (tempId == id && tempPassword == password)
            {
                 Console.WriteLine("Login Successful!!");
                 Console.WriteLine("\n----------PROFILE----------\n");
                 Console.WriteLine("Name: "+name);
                 Console.WriteLine("Id: " +id);
                 Console.WriteLine("Phone Number: " + PhoneNo);
                 Console.WriteLine("\n");
            }
            else 
            {
                Console.WriteLine("Login Failed!! Try Again.");
            }

        }

        public void SignUp(int value)
        {
            Console.Write("Enter Your Name\n-");
            name = Console.ReadLine();
            Console.Write("Enter Your Password\n-");
            password = Console.ReadLine();
            Console.Write("Enter Your Phone Number\n-");
            PhoneNo = Console.ReadLine();
            id = value;

            Console.WriteLine("User Added!!");
            Console.WriteLine("\n--- Your id is "+id+"\n");
        }
    
    }
}
